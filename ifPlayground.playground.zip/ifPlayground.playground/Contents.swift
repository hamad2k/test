func loveCalculator(){
    let loveScore = Int.random(in: 0...100)
    print(loveScore)
    if loveScore > 80 {
        print("you love your each other")
    }
    if loveScore > 40 && loveScore <= 80 {
        print("Mentos and coke")
    } else {
        print("you will be forever alone!")
    }
}

loveCalculator()
